package com.hotelreservas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelReservasApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelReservasApplication.class, args);
	}

}
